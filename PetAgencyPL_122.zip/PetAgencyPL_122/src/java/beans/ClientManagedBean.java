/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import entities.Adoption;
import entities.Pet;
import entities.User;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;

/**
 *
 * @author Student
 */
@Named(value = "clientManagedBean")
@RequestScoped
public class ClientManagedBean {

    /**
     * Creates a new instance of ClientManagedBean
     */
    
    public ClientManagedBean() {
    }
     private String userName; 
    private String email; 
    private String password; 
    private List<User> userdetails; 
    
    private String petname;
    private Integer petage;
    private String petspecies;
    private String petbreed;
    private Integer petuserid;
    private List<Pet> petdetails; 
    
    private Integer adopteruserid;
    private Integer adoptedpetid;
    private List<Adoption> adoptiondetails;

    public Integer getAdopteruserid() {
        return adopteruserid;
    }

    public void setAdopteruserid(Integer adopteruserid) {
        this.adopteruserid = adopteruserid;
    }

    public Integer getAdoptedpetid() {
        return adoptedpetid;
    }

    public void setAdoptedpetid(Integer adoptedpetid) {
        this.adoptedpetid = adoptedpetid;
    }

    public List<Adoption> getAdoptiondetails() {
        return adoptiondetails;
    }

    public void setAdoptiondetails(List<Adoption> adoptiondetails) {
        this.adoptiondetails = adoptiondetails;
    }

    public String getPetname() {
        return petname;
    }

    public void setPetname(String petname) {
        this.petname = petname;
    }

    public Integer getPetage() {
        return petage;
    }

    public void setPetage(Integer petage) {
        this.petage = petage;
    }

    public String getPetspecies() {
        return petspecies;
    }

    public void setPetspecies(String petspecies) {
        this.petspecies = petspecies;
    }

    public String getPetbreed() {
        return petbreed;
    }

    public void setPetbreed(String petbreed) {
        this.petbreed = petbreed;
    }

    public Integer getPetuserid() {
        return petuserid;
    }

    public void setPetuserid(Integer petuserid) {
        this.petuserid = petuserid;
    }

    public List<Pet> getPetdetails() {
        return petdetails;
    }

    public void setPetdetails(List<Pet> petdetails) {
        this.petdetails = petdetails;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<User> getUserdetails() {
        return userdetails;
    }

    public void setUserdetails(List<User> userdetails) {
        this.userdetails = userdetails;
    }
    
    
    
    
    
     public String getUsersList(){ 
        //get list of users 
    UsersResource_JerseyClient BpClient = new 
    UsersResource_JerseyClient(); 
    GenericType<List<User>> gType = new GenericType<List<User>>() {}; 
    List<User> persons = (List<User>) BpClient.getUsers(gType); 
    List<User> listofusers = new ArrayList<User>(); 
    for (User p : persons) { 
    listofusers.add(p); 
    } 
    userdetails = listofusers; 
    return "List of Users"; 
    } 
    public String addUser() { 
    //Registration for New Users  
    UsersResource_JerseyClient BpClient1 = new 
    UsersResource_JerseyClient(); 
    User b = new User(); 
    b.setEmail(email); 
    b.setUserName(userName); 
    b.setPassword(password); 
    BpClient1.CreateUsers(b); 
    return "New User Added"; 
    }
    
    public String getPetsList(){ 
        //get list of users 
    PetsResource_JerseyClient BpClient = new 
    PetsResource_JerseyClient(); 
    GenericType<List<Pet>> gType = new GenericType<List<Pet>>() {}; 
    List<Pet> persons = (List<Pet>) BpClient.getPets(gType); 
    List<Pet> listofpets = new ArrayList<Pet>(); 
    for (Pet p : persons) { 
    listofpets.add(p); 
    } 
    petdetails = listofpets; 
    return "List of Pets"; 
    } 
    
     public String addPet() { 
    //Registration for New Users  
    PetsResource_JerseyClient BpClient1 = new 
    PetsResource_JerseyClient(); 
    Pet p = new Pet(); 
    p.setPetName(petname); 
    p.setPetAge(petage);
    p.setPetSpecies(petspecies);
    p.setPetBreed(petbreed);
    User u=new User();
    u.setUserID(petuserid);
    p.setUserID(u);
    BpClient1.CreatePets(p); 
    return "New Pet Added"; 
    }
     
      public String getAdoptionsList(){ 
        //get list of users 
    AdoptionsResource_JerseyClient BpClient = new 
    AdoptionsResource_JerseyClient(); 
    GenericType<List<Adoption>> gType = new GenericType<List<Adoption>>() {}; 
    List<Adoption> persons = (List<Adoption>) BpClient.getAdopters(gType); 
    List<Adoption> listofadopters = new ArrayList<Adoption>(); 
    for (Adoption p : persons) { 
    listofadopters.add(p); 
    } 
    adoptiondetails = listofadopters; 
    return "List of Adoptions"; 
    } 
    
     public String addAdoption() { 
    //Registration for New Users  
    AdoptionsResource_JerseyClient BpClient1 = new 
    AdoptionsResource_JerseyClient(); 
    Adoption a = new Adoption(); 
   
    User u=new User();
    u.setUserID(adopteruserid);
    Pet p=new Pet();
    p.setPetID(adoptedpetid);
    a.setUserID(u);
    a.setPetID(p);
    BpClient1.CreateAdoptions(a); 
    return "New Adoption Added"; 
    }
     
     
    static class UsersResource_JerseyClient {

        private WebTarget webTarget;
        private Client client;
        private static final String BASE_URI = "http://localhost:8080/PetAgencyALY_122/webresources";

        public UsersResource_JerseyClient() {
            client = javax.ws.rs.client.ClientBuilder.newClient();
            webTarget = client.target(BASE_URI).path("Items");
        }

        public <T> T getUsers(GenericType<T> responseType) throws ClientErrorException {
            WebTarget resource = webTarget;
            return resource.request(javax.ws.rs.core.MediaType.APPLICATION_XML).get(responseType);
        }

        public Response CreateUsers(Object requestEntity) throws ClientErrorException {
            return webTarget.request(javax.ws.rs.core.MediaType.APPLICATION_XML).post(javax.ws.rs.client.Entity.entity(requestEntity, javax.ws.rs.core.MediaType.APPLICATION_XML), Response.class);
        }

        public void close() {
            client.close();
        }
    }

    static class PetsResource_JerseyClient {

        private WebTarget webTarget;
        private Client client;
        private static final String BASE_URI = "http://localhost:8080/PetAgencyALY_122/webresources";

        public PetsResource_JerseyClient() {
            client = javax.ws.rs.client.ClientBuilder.newClient();
            webTarget = client.target(BASE_URI).path("PetItems");
        }

        public <T> T getPets(GenericType<T> responseType) throws ClientErrorException {
            WebTarget resource = webTarget;
            return resource.request(javax.ws.rs.core.MediaType.APPLICATION_XML).get(responseType);
        }

        public Response CreatePets(Object requestEntity) throws ClientErrorException {
            return webTarget.request(javax.ws.rs.core.MediaType.APPLICATION_XML).post(javax.ws.rs.client.Entity.entity(requestEntity, javax.ws.rs.core.MediaType.APPLICATION_XML), Response.class);
        }

        public void close() {
            client.close();
        }
    }

    static class AdoptionsResource_JerseyClient {

        private WebTarget webTarget;
        private Client client;
        private static final String BASE_URI = "http://localhost:8080/PetAgencyALY_122/webresources";

        public AdoptionsResource_JerseyClient() {
            client = javax.ws.rs.client.ClientBuilder.newClient();
            webTarget = client.target(BASE_URI).path("AItems");
        }

        public Response CreateAdoptions(Object requestEntity) throws ClientErrorException {
            return webTarget.request(javax.ws.rs.core.MediaType.APPLICATION_XML).post(javax.ws.rs.client.Entity.entity(requestEntity, javax.ws.rs.core.MediaType.APPLICATION_XML), Response.class);
        }

        public <T> T getAdopters(GenericType<T> responseType) throws ClientErrorException {
            WebTarget resource = webTarget;
            return resource.request(javax.ws.rs.core.MediaType.APPLICATION_XML).get(responseType);
        }

        public void close() {
            client.close();
        }
    }

    
    }
    
    
    
    
    
    

