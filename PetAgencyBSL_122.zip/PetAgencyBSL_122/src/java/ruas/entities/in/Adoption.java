/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ruas.entities.in;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Student
 */
@Entity
@Table(name = "adoption")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Adoption.findAll", query = "SELECT a FROM Adoption a")
    , @NamedQuery(name = "Adoption.findByAdoptionID", query = "SELECT a FROM Adoption a WHERE a.adoptionID = :adoptionID")})
public class Adoption implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "AdoptionID")
    private Integer adoptionID;
    @JoinColumn(name = "UserID", referencedColumnName = "UserID")
    @ManyToOne(optional = false)
    private User userID;
    @JoinColumn(name = "PetID", referencedColumnName = "PetID")
    @ManyToOne(optional = false)
    private Pet petID;

    public Adoption() {
    }

    public Adoption(Integer adoptionID) {
        this.adoptionID = adoptionID;
    }

    public Integer getAdoptionID() {
        return adoptionID;
    }

    public void setAdoptionID(Integer adoptionID) {
        this.adoptionID = adoptionID;
    }

    public User getUserID() {
        return userID;
    }

    public void setUserID(User userID) {
        this.userID = userID;
    }

    public Pet getPetID() {
        return petID;
    }

    public void setPetID(Pet petID) {
        this.petID = petID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (adoptionID != null ? adoptionID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Adoption)) {
            return false;
        }
        Adoption other = (Adoption) object;
        if ((this.adoptionID == null && other.adoptionID != null) || (this.adoptionID != null && !this.adoptionID.equals(other.adoptionID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ruas.entities.in.Adoption[ adoptionID=" + adoptionID + " ]";
    }
    
}
